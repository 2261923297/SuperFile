#pragma once
#include <iostream> 
#include <memory>

typedef int NodeDataType;
typedef struct Node {
public:
	typedef NodeDataType data_t;
	Node(data_t val) {
		data = val;
		left = right = nullptr;
/*
		std::cout << "node_data = " << data << " is created!" 
			<< "\nleft = " << (int)left
			<< "\nright = " << right	
			<< std::endl;

*/
	}	
	
	~Node() {
		
	}
public:
	data_t data;
	Node* left;
	Node* right;
public:
	const data_t& getData() { return data; }
} Node;

class tree {
public: 
    typedef std::shared_ptr<tree> ptr; 
    
    tree(); 
    virtual ~tree();

	void addNode(Node::data_t val);
	void addNode(Node* node);
	
	int size() { return m_nodeNum; }
	int compare(const Node& n1, const Node& n2);
	
	void postorder(const Node* node);//后续遍历

	void inorder(const Node* node); //中序遍历

	void preorder(const Node* node);//前序遍历

	const Node* getRoot() { return m_root; }

	void delTree(Node* root);
protected:
	void insert(Node* tree, Node* node);
private: 
    	Node* m_root;
	
	int m_leafNum;
	int m_nodeNum;
	int m_depth;


}; // tree
    
