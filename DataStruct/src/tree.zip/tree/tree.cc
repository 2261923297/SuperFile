#include "tree.h"
#include <string>

tree::tree() {
	m_root = nullptr;
	
	m_leafNum = 0;
	m_nodeNum = 0;
	m_depth = 0;
}
    
tree::~tree() {
    delTree(m_root);
}
int tree::compare(const Node& n1, const Node& n2) {
	if(n1.data >= n2.data) {
		return 1;
	} 

	return 0;
}

void tree::delTree(Node* root) {
	if(root == nullptr) 
		return;
	if(root->left != nullptr) {
		delTree(root->left);
	}
	if(root->right != nullptr) {
		delTree(root->right);
	}
	std::cout << "del node_data = " << root->data << std::endl;
	m_nodeNum--;
}

void tree::insert(Node* tree, Node* node) {
	
	if(compare(*tree, *node)) {
		if(tree->left == nullptr) {
/*
			std::cout << "node_data = " << tree->data
				<< ", left = " << node->data
				<< std::endl;
*/
			tree->left = node;
		} else {
			insert(tree->left, node);
		}
	} else {
		if(tree->right == nullptr) {
			tree->right = node;
/*
			std::cout << "node_data = " << tree->data
				<< ", right = " << node->data
				<< std::endl;
*/
		} else {
			insert(tree->right, node);
		}
	}

}

void tree::addNode(Node::data_t val) {
	Node* node = new Node(val);
	addNode(node);
}

void tree::addNode(Node* node) {
	if(node == nullptr) 
		return;
	m_nodeNum++;
	if(m_root == nullptr) {
		m_root = node;
		return ;
	}
	Node* tmpNode = m_root;
	insert(tmpNode, node);
}

void tree::postorder(const Node* node) {
	if(node->left) {
		postorder(node->left);
	} 
	if(node->right) {
		postorder(node->right);
	}
	std::cout << node->data << ", ";
}//后续遍历

void tree::inorder(const Node* node) {
	if(node->left != nullptr) {
		inorder(node->left);
	}
	std::cout << node->data << ", ";
	if(node->right != nullptr) {
		inorder(node->right);
	}
}//中序遍历

void tree::preorder(const Node* node) {
	//std::cout << "preorder " << std::endl;
	std::cout << node->data << ", ";
	if(node == nullptr) {
		std::cout << "order is nullptr, cat^t oder" << std::endl;
	}
	if(node->left != nullptr) {
		preorder(node->left);
	} 
	if(node->right != nullptr) {
		preorder(node->right);
	}

}//前序遍历
   
